# Documents Index

This repo includes documents that explain how to use and build the product. It also provides detailed information about the project.
New update
- [Microsoft official docs](official-docs.md)