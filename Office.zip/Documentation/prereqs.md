.NET native prerequisites
==============================

* [Windows Prerequisites](https://docs.microsoft.com/dotnet/core/install/windows)
* [macOS Prerequisites](https://docs.microsoft.com/dotnet/core/install/macos)
* [Linux Prerequisites](https://docs.microsoft.com/dotnet/core/install/linux)
* [.NET Supported OS Lifecycle Policy](https://github.com/dotnet/core/blob/main/os-lifecycle-policy.md)
