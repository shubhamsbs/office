# Contributing

See [Contributing](https://github.com/dotnet/runtime/blob/main/CONTRIBUTING.md) for information about coding styles, source structure, making pull requests, and more.

# Repos

See the [.NET Repos](Documentation/core-repos.md) to find a repo to contribute to.
